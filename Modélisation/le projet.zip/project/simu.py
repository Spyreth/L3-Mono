import numpy as np
import matplotlib.pyplot as plt
from matplotlib import animation
from numba import njit
from initialisation.positions import *
from initialisation.vitesses import *

# Constantes
L_box = 40  #bord boite en Angstrom
D = 2 #dimension
nb_part = 16  #nombre de particules
dt = 0.1  #pas de temps en ps
m_part = 20  #masse particules en ua
nb_pas = 200

# Paramètres du potentiel Lennard-Jones
sig = 3.4 #paramètres de distance du potentiel en Angstrom
Kb = 1.38e-23
eps = 120   #paramètre décrivant la profondeur du puit de Lennard-Jones, énergie
cutoff = 3.2*sig

# Paramètres de l'animation
rayon = 2


@njit
def reflectBC(r_0, r_1, nb_part, L_box, D):
    """
    Applique les conditions limites d'une boîte solide

    Args:
        r_0 (array): Positions des particules à t0
        r_1 (array): Positions des particules à t1

    Returns:
        r_0 (array): Positions des particules à t0 corrigée
        r_1 (array): Positions des particules à t1 corrigée
    """
    
    r0 = r_0
    r1 = r_1
    
    for i in range(nb_part):  #pour chaque particule
        for j in range(D):   #dans chaque dimension
            a = 1
            #si r1 sort de la boite en 0 ou en L, on inverse les positions
            #if r1[i][j]<0:
                #r1[i][j] = -r1[i][j]
                #r0[i][j] = -r0[i][j]
            #if r1[i][j]>L_box:
                #r1[i][j] = 2.0*L_box-r1[i][j]
                #r0[i][j] = 2.0*L_box-r0[i][j]
    return r0, r1


@njit
def dLJpot(r, i, sig, eps, cut_off):
    
    """
    Gradient du potentiel de Lennard-Jones pour une particule

    Args:
        r (array): Positions des particules
        i (float): Index de la particule
        sig (float): Taille des particules
        eps (float): Profondeur du puit

    Returns:
        dLJP (array): Gradient du potentiel de la particule
    """
    
    dpart = r-r[i] #distance entre la i-eme particule et les autres
    dpart = np.delete(dpart,2*i)
    dpart = np.delete(dpart,2*i)  #on retire le i-eme element car pas d'interaction d'une particule avec elle-même
    dpart = dpart.reshape(nb_part-1,2)
    dpart_cut = np.empty((nb_part-1,D), dtype=float)
    dpart_calc_cut = np.empty((nb_part-1,1), dtype=float)

    incr = 0
    for elem in dpart :
        distance_calc = np.sqrt(elem[0]**2 + elem[1]**2)
    
        if distance_calc <= cut_off:
            dpart_cut[incr] = elem   #on ajoute cet élément dans l'array
            dpart_calc_cut[incr] = distance_calc
            incr +=1
    
    dpart_cut = dpart_cut[:incr]
    dpart_calc_cut = dpart_calc_cut[:incr]

    r8 =  (sig**6)*(1.0/dpart_calc_cut)**8
    r14 = 2.0*(sig**12)*(1.0/dpart_calc_cut)**14
    r814 = r14-r8
    r814v = (dpart_cut)*r814
    dLJP = 24.0*eps*np.sum(r814v,axis=0)
    
    return dLJP


@njit
def dLJpotnumb(r, i, sig, eps, cut_off):
    
    """
    Gradient du potentiel de Lennard-Jones pour une particule

    Args:
        r (array): Positions des particules
        i (float): Index de la particule
        sig (float): Taille des particules
        eps (float): Profondeur du puit

    Returns:
        dLJP (array): Gradient du potentiel de la particule
    """
    
    dpart = r-r[i] #distance entre la i-eme particule et les autres
    dpart = np.delete(dpart,2*i)
    dpart = np.delete(dpart,2*i)  #on retire le i-eme element car pas d'interaction d'une particule avec elle-même
    dpart = dpart.reshape(nb_part-1,2)
    dpart_cut = np.empty((nb_part-1,D), dtype=float)
    dpart_calc_cut = np.empty((nb_part-1,1), dtype=float)

    incr = 0
    for elem in dpart :
        distance_calc = np.sqrt(elem[0]**2 + elem[1]**2)
    
        if distance_calc <= cut_off:
            dpart_cut[incr] = elem   #on ajoute cet élément dans l'array
            dpart_calc_cut[incr] = distance_calc
            incr +=1
    
    dpart_cut = dpart_cut[:incr]
    dpart_calc_cut = dpart_calc_cut[:incr]

    r8 =  (sig**6)*(1.0/dpart_calc_cut)**8
    r14 = 2.0*(sig**12)*(1.0/dpart_calc_cut)**14
    r814 = r14-r8
    r814v = (dpart_cut)*r814
    dLJP = 24.0*eps*np.sum(r814v,axis=0)
    
    return dLJP


@njit
def verlet(r0, v0, force, pas, m) :
    
    v1_2 = v0 + force*pas/(2*m)
    r1 = r0 + v1_2*pas/2
    v1 = v1_2 + force*pas/(2*m)

    return r1, v1



@njit
def update(r_0, v_0, pas, m) :
    
    force = np.empty((nb_part,D), dtype=float)
    for i in range(nb_part):
        force[i] = dLJpot(r_0, i, sig, eps, cutoff)
    r_1, v_1 = verlet(r_0, v_0, force, pas, m)
    r_1, v_1 = reflectBC(r_1, v_1, nb_part, L_box, D)
    
    return r_1, v_1



#r = random_pos(nb_part, L_box, D)
r, nb_part = pos_cristal2D(4, L_box)
v = random_vit(nb_part, L_box, D)

position = np.empty((nb_pas, nb_part, 2), np.float64)

for i in range(nb_pas):
    r, v = update(r, v, dt, m_part)
    position[i] = r



#################################################
######## ANIMATION ###################################

def init():
    global position, rayon, nb_part, ax, particles
    
    for i in range(nb_part):
        circle = plt.Circle((-10, -10), rayon,facecolor='red', edgecolor='black', lw=1)
        ax.add_patch(circle)
        particles.append(circle)
    return particles 

def animate(i):
    global position, particles

    for j in range(nb_part):
        particles[j].center = (position[i,j, 0], position[i,j, 1])

    return particles 



fig, ax = plt.subplots()
ax.set_xlim(0, L_box)
ax.set_ylim(0, L_box)
ax.set_aspect('equal')
ax.axes.xaxis.set_visible(False)
ax.axes.yaxis.set_visible(False)  

particles = []

anim = animation.FuncAnimation(fig, animate, frames=nb_pas, interval=10, blit=True, init_func=init, repeat=False)

writergif = animation.PillowWriter(fps=20)
anim.save('gaz.gif', writer=writergif)
#writergif = animation.FFMpegWriter(fps=20)
#anim.save('gaz.mp4', fps=20, dpi=200)


